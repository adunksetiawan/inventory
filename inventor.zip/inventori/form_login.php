<div id="wrapper">
<?php error_reporting(0);?>
<?php include "kepala1.php"; ?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Login User</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" href="style_login.css" type="text/css"  />
</head>
<body>
<center>

<table>
  <tr>
    <th width="120" height="21">User </th>
    <th width="101">: admin</th>
  </tr>
</table>
<table>
  <tr>
    <th width="121">Password</th>
    <th width="100">: admin</th>
  </tr>
</table>
</center>
<p>&nbsp;</p>
<?php include "form_login1.php"; ?>

<?php include "kaki.php"; ?>

</div>
</body>
</html>