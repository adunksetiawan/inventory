<table class="sikil" cellspacing="0" cellpading="0" align="center" border="1" bgcolor="#FF6699">
	<tr>
		<td width="900px" align="center">Copyright &copy; 2014 <a href="https://www.facebook.com/Sigit.Dwi.Prasetyo.sdp">Sigit Dwi Prasetya</a> </td>
	</tr>
</table>
</body>
</html>
