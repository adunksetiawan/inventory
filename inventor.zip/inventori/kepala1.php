<html>
<head>
	<title>UAS WEB PROGRAMMING</title>
</head>
<body>
<table class="sirah" cellspacing="1" cellpading="1" align="center" border="1" width="900px">
	<tr>
		<td align="center" height="49" bgcolor="#FF6699">
        
        <div id="box"> Silahkan masukkan user dan password</div>
        </td>
	</tr>
    <tr>
    <td align="center" height="10"><marquee>UAS WEB PROGRAMMING SISTEM INVENTORI || UAS WEB PROGRAMMING SISTEM INVENTORI || UAS WEB PROGRAMMING SISTEM INVENTORI ||</marquee></td></tr>
	
</table>

